const ListaAutos = [
  {
    id: 1,
    modelo: "MDX",
    marca: "Acura",
    precio: "$58981.34",
    anio: 2012,
    imagen: "https://qesot.com/img_dir/cars/32166-acura-mdx-iii-2017-1.jpeg",
  },
];
export default ListaAutos;
module.exports = {
  ListaAutos,
};
